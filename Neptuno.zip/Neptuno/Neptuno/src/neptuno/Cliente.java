/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neptuno;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author samue
 */
public class Cliente {

    String idCliente;
    String nombreCompañía;
    String nombreContacto;
    String cargoContacto;
    String dirección;
    String ciudad;
    String región;
    String códpostal;
    String país;
    String teléfono;
    String fax;
    
    private String user;
    private String password;
    private String db;
    private String host;
    private String url;
    private Connection conn = null;
    private Statement stm;// permite guardar comandos SQL

    public Cliente(String usuario, String contraseña, String bd, String servidor)
    {
        this.user = usuario;
        this.password = contraseña;
        this.db = bd;
        this.host = servidor;
	//quitar el comentario cuando se usa MySql 8 y superior
	this.url = "jdbc:mysql://" + this.host + "/" + this.db+"?useSSL=false&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
    }

    public void conectarClientes()
    {
        try {
                Class.forName("com.mysql.cj.jdbc.Driver");//com.mysql.cj.jdbc.Driver
                conn = DriverManager.getConnection(url, user, password);
                if (conn != null)
                {
                    System.out.println("Conexión a base de datos "+url+" ... Ok");
                    stm = conn.createStatement();
                }
            }   
        catch(SQLException ex) {
            System.out.println("Problema en la conexión a la base de datos "+url);
        }
        catch(ClassNotFoundException ex) {
            System.out.println(ex);
        }
    }

    //Método para cerrar la conexión a la BD
    public void cerrar()
    {
        try{
            if(conn !=null){
                stm.close();
                conn.close();
                System.out.println("Conexión cerrada");
            }
        }
        catch(SQLException ex){
            System.out.println(ex);
        }
    }

    public String guardarCliente(String idCliente,String nombreCompañía,String nombreContacto,String cargoContacto,String dirección,String ciudad,String región,String códpostal,String país,String teléfono,String fax )
    {
        try {
            stm.execute("INSERT INTO clientes (idCliente,nombreCompañía,nombreContacto,cargoContacto,dirección,ciudad,región,códpostal,país,teléfono,fax) VALUES ('"+idCliente+"','"+nombreCompañía+"','"+nombreContacto+"','"+cargoContacto+"','"+dirección+"','"+ciudad+"','"+región+"','"+códpostal+"','"+país+"','"+teléfono+"','"+fax+"' )");
            return "El registro se ha guardado con éxito";
        } catch (SQLException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
            return "El registro no se ha podido guardar";
        }
        
    }
    
    public String modificarCliente(String idCliente,String nombreCompañía,String nombreContacto,String cargoContacto,String dirección,String ciudad,String región,String códpostal,String país,String teléfono,String fax )
    {
        try {
            stm.execute("UPDATE clientes SET nombreCompañía='"+nombreCompañía+"',nombreContacto='"+nombreContacto+"',direccion='"+dirección+"',ciudad='"+ciudad+"',región='"+región+"',códpostal='"+códpostal+"',pais='"+país+"',telefono='"+teléfono+"',fax='"+fax+"' WHERE idClientes='"+idCliente+"' ");
            return "El registro se ha modificado con éxito";
        } catch (SQLException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
            return "El registro no se ha modificado";
        }
    }
    
    public String eliminarCliente(String id)
    {
        try {
            stm.execute(" DELETE FROM cliente WHERE idCliente='"+id+"' ");
            return "Registro borrado";
        } catch (SQLException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
            return "No se pudo borrar";
        }
    }
    
    public ResultSet buscarPorId(String id) throws SQLException
    {
        return stm.executeQuery("SELECT * FROM cliente where idCliente like '"+ id +"%'");
    }
    
    public ResultSet buscarPorCompañía(String compañía) throws SQLException
            
    {
        return stm.executeQuery("SELECT * FROM cliente where nombreCompañía like '"+ compañía +"%'");
       
    }
    

    
    public static void main(String[] args) {
        
        
    }
    
}
