/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neptuno;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.PrintJob;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author samue
 */
public class FrmFacturas extends javax.swing.JInternalFrame implements KeyListener {

    Font fuente = new Font("Dialog", Font.PLAIN, 10);
    PrintJob pj; 
    Graphics pagina;
    static int inc = 110;
    int num=00001;
    int contador=0;
//    int cliente=Integer.parseInt(cbxCliente.getSelectedItem().toString());
    
    public void keyTyped(KeyEvent e) {} //tecla de función son las f
    public void keyReleased(KeyEvent e) {} //Cuando soltamos la tecla
    public void keyPressed(KeyEvent e) //Presionamos la tecla
    {
       if (e.getKeyCode()==32 && e.getKeyCode()==80 )
       {
           pj = Toolkit.getDefaultToolkit().getPrintJob(new Frame(), "PRUEBA", null);
           this.imprimir((String)cbxCliente.getSelectedItem(),txtFecha.getText(),txtDireccion.getText(),txtTelefono.getText(),(String)cbxCodigo1.getSelectedItem(),(String)cbxCodigo2.getSelectedItem(),(String)cbxCodigo3.getSelectedItem(),(String)cbxCodigo4.getSelectedItem(),txt1.getText(),txt5.getText(),txt9.getText(),txt13.getText(),txt2.getText(),txt6.getText(),txt10.getText(),txt14.getText(),txt3.getText(),txt7.getText(),txt11.getText(),txt15.getText(),txt4.getText(),txt8.getText(),txt12.getText(),txt16.getText(),txtsubtotal.getText(),txtdescuento.getText(),txtiva.getText(),txttotal.getText());
       }
    }
    
    public void imprimir(String nombre, String fecha, String direccion, String telefono, String codigo1, String codigo2,
                        String codigo3, String codigo4, String Descripcion1, String Descripcion2, String Descripcion3,
                        String Descripcion4,String Cantidad1, String Cantidad2,String Cantidad3, String Cantidad4, 
                        String Precio1, String Precio2, String Precio3, String Precio4, String Subtotal1, String Subtotal2,
                        String Subtotal3, String Subtotal4, String Subtotal, String Descuento, String iva, String Total){
        try{
            pagina = pj.getGraphics();
            pagina.setFont(fuente);
            pagina.setColor(Color.black);
            pagina.drawString(nombre, 150,100);
            pagina.drawString(fecha, 150, inc+=30);
            pagina.drawString(direccion, 150, inc+=30);
            pagina.drawString(telefono, 150, inc+=30);
            pagina.drawString(codigo1, 150, inc+=30);
            pagina.drawString(codigo2, 150, inc+=30);
            pagina.drawString(codigo3, 150, inc+=30);
            pagina.drawString(codigo4, 150, inc+=30);
            pagina.drawString(Descripcion1, 150, inc+=30);
            pagina.drawString(Descripcion2, 150, inc+=30);
            pagina.drawString(Descripcion3, 150, inc+=30);
            pagina.drawString(Descripcion4, 150, inc+=30);
            pagina.drawString(Cantidad1, 150, inc+=30);
            pagina.drawString(Cantidad2, 150, inc+=30);
            pagina.drawString(Cantidad3, 150, inc+=30);
            pagina.drawString(Cantidad4, 150, inc+=30);
            pagina.drawString(Precio1, 150, inc+=30);
            pagina.drawString(Precio2, 150, inc+=30);
            pagina.drawString(Precio3, 150, inc+=30);
            pagina.drawString(Precio4, 150, inc+=30);
            pagina.drawString(Subtotal1, 150, inc+=30);
            pagina.drawString(Subtotal2, 150, inc+=30);
            pagina.drawString(Subtotal3, 150, inc+=30);
            pagina.drawString(Subtotal4, 150, inc+=30);
            pagina.drawString(Subtotal, 150, inc+=30);
            pagina.drawString(Descuento, 150, inc+=30);
            pagina.drawString(iva, 150, inc+=30);
            pagina.drawString(Total, 150, inc+=30);
            pagina.dispose();
            pj.end();
    }catch(Exception e){
        JOptionPane.showMessageDialog(null, "Impresión cancelada...", "Aviso",JOptionPane.WARNING_MESSAGE);
    }
}


    
    
    public FrmFacturas() {
        initComponents();
        String idCliente;
        Font fuente = new Font("Dialog", Font.PLAIN, 10);
        DateFormat dateFormat = new SimpleDateFormat ("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        txtFecha.setText(dateFormat.format(date));
        
        
        
        
        JButton[]botones={btnNuevo, btnGuardar, btnModificar, btnEliminar, btnImprimir};
        int Separacion=50;
        for (JButton btn:botones)
        {
            btn.setBounds(Separacion,20,40,40);
            Separacion+=80;
        }
        //Cuadro de textos
        int largo=70;
        int ancho=20;
        int Separacion1=130;
        JTextField[]texto={txt1,txt2,txt3,txt4};
        
        for (JTextField txt:texto)
        {
            txt.setBounds(Separacion1,230,largo,ancho);
            Separacion1+=110;
            
        }
        
        JTextField[]texto1={txt5,txt6,txt7,txt8};
        int Separacion2=130;
        for (JTextField txt:texto1)
        {
            //sumando 40 para abajo
            txt.setBounds(Separacion2,270,largo,ancho);
            Separacion2+=110;
        }
        
        JTextField[]texto2={txt9,txt10,txt11,txt12};
        int Separacion3=130;
        for (JTextField txt:texto2)
        {
            //sumando 40 para abajo
            txt.setBounds(Separacion3,310,largo,ancho);
            Separacion3+=110;
        }
        
        JTextField[]texto3={txt13,txt14,txt15,txt16};
        int Separacion4=130;
        for (JTextField txt:texto3)
        {
            //sumando 40 para abajo
            txt.setBounds(Separacion4,350,largo,ancho);
            Separacion4+=110;
        }
        
        // Labels superiores al cuadro de texto
        JLabel[] labels={lblCodigo,lblDescripcion,lblCantidad,lblPrecio,lblSubtotal};
        int separacion5=30;
        for(JLabel lbl:labels)
        {
            lbl.setBounds(separacion5, 200, 70, 20);
            separacion5+=110;
        }

        //Cuadro inferior de IVA
        JLabel[] labels1={lblSubt,lblDescuento,lblIVA,lblTotal};
        int separacion=390;
        for(JLabel lbl:labels1) 
        {
            lbl.setBounds(315,separacion,60,20);
            separacion+=25;
        }
        
        JTextField[]iva={txtDescuento,txtIva};
        int doble=415;
        for (JTextField txt:iva)
        {
            txt.setBounds(390,doble,35,20);
            doble+=25;
        }
        
        //Porcentajes
        JLabel[] porcentajes={lblpor,lblpor1};
        int espacio=415;
        for(JLabel lbl:porcentajes)
        {
            lbl.setBounds(430, espacio, 25, 20);
            espacio+=25;
        }
        
        //cuadros de texto iva,porcentaje,subtotal,total
        JTextField[]ult={txtsubtotal,txtdescuento,txtiva,txttotal};
        int disy=390;
        for (JTextField txt:ult)
        {
            txt.setBounds(450,disy,60,20);
            disy+=25;
        }
    }



    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel15 = new javax.swing.JLabel();
        btnImprimir = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        cbxCodigo1 = new javax.swing.JComboBox<>();
        lblCodigo = new javax.swing.JLabel();
        lblDescripcion = new javax.swing.JLabel();
        lblCantidad = new javax.swing.JLabel();
        lblPrecio = new javax.swing.JLabel();
        lblSubtotal = new javax.swing.JLabel();
        txt1 = new javax.swing.JTextField();
        txt2 = new javax.swing.JTextField();
        txt3 = new javax.swing.JTextField();
        txt4 = new javax.swing.JTextField();
        cbxCliente = new javax.swing.JComboBox<>();
        cbxCodigo2 = new javax.swing.JComboBox<>();
        cbxCodigo3 = new javax.swing.JComboBox<>();
        cbxCodigo4 = new javax.swing.JComboBox<>();
        txt5 = new javax.swing.JTextField();
        txt6 = new javax.swing.JTextField();
        txt7 = new javax.swing.JTextField();
        txt8 = new javax.swing.JTextField();
        txt9 = new javax.swing.JTextField();
        txt13 = new javax.swing.JTextField();
        txt10 = new javax.swing.JTextField();
        txt11 = new javax.swing.JTextField();
        txt12 = new javax.swing.JTextField();
        txt14 = new javax.swing.JTextField();
        txt15 = new javax.swing.JTextField();
        txt16 = new javax.swing.JTextField();
        lblSubt = new javax.swing.JLabel();
        lblDescuento = new javax.swing.JLabel();
        lblIVA = new javax.swing.JLabel();
        lblTotal = new javax.swing.JLabel();
        lblNumero = new javax.swing.JLabel();
        txtDescuento = new javax.swing.JTextField();
        txtIva = new javax.swing.JTextField();
        lblpor = new javax.swing.JLabel();
        lblpor1 = new javax.swing.JLabel();
        txtsubtotal = new javax.swing.JTextField();
        txtdescuento = new javax.swing.JTextField();
        txtiva = new javax.swing.JTextField();
        txttotal = new javax.swing.JTextField();

        jLabel15.setText("jLabel15");

        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        setPreferredSize(new java.awt.Dimension(580, 600));
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameActivated(evt);
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        btnImprimir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/neptuno/imprimir.png"))); // NOI18N
        btnImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimirActionPerformed(evt);
            }
        });
        getContentPane().add(btnImprimir);
        btnImprimir.setBounds(380, 10, 40, 40);

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/neptuno/nuevo.png"))); // NOI18N
        btnNuevo.setPreferredSize(new java.awt.Dimension(16, 16));
        getContentPane().add(btnNuevo);
        btnNuevo.setBounds(33, 11, 40, 40);

        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/neptuno/guardar.png"))); // NOI18N
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar);
        btnGuardar.setBounds(123, 11, 40, 40);

        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/neptuno/modificar.png"))); // NOI18N
        getContentPane().add(btnModificar);
        btnModificar.setBounds(213, 11, 40, 40);

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/neptuno/eliminar.png"))); // NOI18N
        getContentPane().add(btnEliminar);
        btnEliminar.setBounds(303, 11, 40, 40);

        jLabel1.setText("Factura");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(139, 69, 50, 14);

        jLabel2.setText("Cliente:");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(39, 110, 50, 14);

        jLabel3.setText("Dirección:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(39, 157, 60, 14);
        getContentPane().add(txtDireccion);
        txtDireccion.setBounds(120, 150, 100, 30);

        jLabel4.setText("Fecha:");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(267, 110, 60, 14);

        jLabel5.setText("Teléfono:");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(267, 157, 50, 14);
        getContentPane().add(txtFecha);
        txtFecha.setBounds(350, 100, 100, 30);
        getContentPane().add(txtTelefono);
        txtTelefono.setBounds(350, 150, 100, 30);

        cbxCodigo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4" }));
        cbxCodigo1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxCodigo1ItemStateChanged(evt);
            }
        });
        getContentPane().add(cbxCodigo1);
        cbxCodigo1.setBounds(40, 230, 31, 20);

        lblCodigo.setText("Código");
        getContentPane().add(lblCodigo);
        lblCodigo.setBounds(50, 200, 50, 14);

        lblDescripcion.setText("Descripción");
        getContentPane().add(lblDescripcion);
        lblDescripcion.setBounds(130, 200, 80, 14);

        lblCantidad.setText("Cantidad");
        getContentPane().add(lblCantidad);
        lblCantidad.setBounds(230, 200, 50, 14);

        lblPrecio.setText("Precio");
        getContentPane().add(lblPrecio);
        lblPrecio.setBounds(330, 200, 50, 14);

        lblSubtotal.setText("SubTotal");
        getContentPane().add(lblSubtotal);
        lblSubtotal.setBounds(410, 200, 60, 14);
        getContentPane().add(txt1);
        txt1.setBounds(130, 230, 6, 20);

        txt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt2ActionPerformed(evt);
            }
        });
        txt2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt2KeyReleased(evt);
            }
        });
        getContentPane().add(txt2);
        txt2.setBounds(220, 230, 6, 20);
        getContentPane().add(txt3);
        txt3.setBounds(310, 230, 6, 20);
        getContentPane().add(txt4);
        txt4.setBounds(400, 230, 6, 20);

        cbxCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxClienteActionPerformed(evt);
            }
        });
        getContentPane().add(cbxCliente);
        cbxCliente.setBounds(120, 110, 50, 20);

        cbxCodigo2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4" }));
        cbxCodigo2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxCodigo2ItemStateChanged(evt);
            }
        });
        getContentPane().add(cbxCodigo2);
        cbxCodigo2.setBounds(40, 270, 31, 20);

        cbxCodigo3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4" }));
        cbxCodigo3.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxCodigo3ItemStateChanged(evt);
            }
        });
        getContentPane().add(cbxCodigo3);
        cbxCodigo3.setBounds(40, 310, 31, 20);

        cbxCodigo4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4" }));
        cbxCodigo4.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxCodigo4ItemStateChanged(evt);
            }
        });
        getContentPane().add(cbxCodigo4);
        cbxCodigo4.setBounds(40, 350, 31, 20);
        getContentPane().add(txt5);
        txt5.setBounds(130, 270, 6, 20);
        getContentPane().add(txt6);
        txt6.setBounds(220, 270, 6, 20);
        getContentPane().add(txt7);
        txt7.setBounds(310, 270, 6, 20);
        getContentPane().add(txt8);
        txt8.setBounds(400, 270, 6, 20);
        getContentPane().add(txt9);
        txt9.setBounds(130, 310, 6, 20);
        getContentPane().add(txt13);
        txt13.setBounds(130, 350, 6, 20);
        getContentPane().add(txt10);
        txt10.setBounds(220, 310, 6, 20);
        getContentPane().add(txt11);
        txt11.setBounds(310, 310, 6, 20);
        getContentPane().add(txt12);
        txt12.setBounds(400, 310, 6, 20);
        getContentPane().add(txt14);
        txt14.setBounds(220, 350, 6, 20);
        getContentPane().add(txt15);
        txt15.setBounds(310, 350, 6, 20);
        getContentPane().add(txt16);
        txt16.setBounds(400, 350, 6, 20);

        lblSubt.setText("Subtotal");
        getContentPane().add(lblSubt);
        lblSubt.setBounds(310, 400, 40, 14);

        lblDescuento.setText("Descuento");
        getContentPane().add(lblDescuento);
        lblDescuento.setBounds(310, 430, 70, 14);

        lblIVA.setText("IVA");
        getContentPane().add(lblIVA);
        lblIVA.setBounds(310, 460, 17, 14);

        lblTotal.setText("TOTAL:");
        getContentPane().add(lblTotal);
        lblTotal.setBounds(310, 490, 60, 14);

        lblNumero.setText("XXXXXXX");
        getContentPane().add(lblNumero);
        lblNumero.setBounds(220, 70, 70, 14);
        getContentPane().add(txtDescuento);
        txtDescuento.setBounds(380, 420, 30, 20);
        getContentPane().add(txtIva);
        txtIva.setBounds(380, 450, 30, 20);

        lblpor.setText("%");
        getContentPane().add(lblpor);
        lblpor.setBounds(420, 420, 20, 14);

        lblpor1.setText("%");
        getContentPane().add(lblpor1);
        lblpor1.setBounds(420, 450, 20, 14);
        getContentPane().add(txtsubtotal);
        txtsubtotal.setBounds(450, 390, 6, 20);
        getContentPane().add(txtdescuento);
        txtdescuento.setBounds(450, 420, 6, 20);
        getContentPane().add(txtiva);
        txtiva.setBounds(450, 450, 6, 20);
        getContentPane().add(txttotal);
        txttotal.setBounds(450, 480, 6, 20);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimirActionPerformed

        pj = Toolkit.getDefaultToolkit().getPrintJob(new Frame(), "PRUEBA", null);
        this.imprimir((String)cbxCliente.getSelectedItem(),txtFecha.getText(),txtDireccion.getText(),txtTelefono.getText(),(String)cbxCodigo1.getSelectedItem(),(String)cbxCodigo2.getSelectedItem(),(String)cbxCodigo3.getSelectedItem(),(String)cbxCodigo4.getSelectedItem(),txt1.getText(),txt5.getText(),txt9.getText(),txt13.getText(),txt2.getText(),txt6.getText(),txt10.getText(),txt14.getText(),txt3.getText(),txt7.getText(),txt11.getText(),txt15.getText(),txt4.getText(),txt8.getText(),txt12.getText(),txt16.getText(),txtsubtotal.getText(),txtdescuento.getText(),txtiva.getText(),txttotal.getText());

    }//GEN-LAST:event_btnImprimirActionPerformed

    private void cbxCodigo1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxCodigo1ItemStateChanged
        try {
            Factura factura = new Factura("root","pearljam99","neptuno", "localhost:3308");
            factura.conectarFactura();
            ResultSet rsProducto1 = factura.consultarProducto(cbxCodigo1.getSelectedItem().toString());
            while (rsProducto1.next())
            {
                txt1.setText(rsProducto1.getObject(1).toString());
                txt3.setText(rsProducto1.getObject(2).toString());
                
            }
            factura.cerrarFactura();
        } catch (SQLException ex) {
            Logger.getLogger(FrmFacturas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_cbxCodigo1ItemStateChanged

    private void cbxCodigo2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxCodigo2ItemStateChanged
        try {
            Factura factura = new Factura("root","pearljam99","neptuno", "localhost:3308");
            factura.conectarFactura();
            ResultSet rsProducto1 = factura.consultarProducto(cbxCodigo2.getSelectedItem().toString());
            while (rsProducto1.next())
            {
                txt5.setText(rsProducto1.getObject(1).toString());
                txt7.setText(rsProducto1.getObject(2).toString());
                
            }
            factura.cerrarFactura();
        } catch (SQLException ex) {
            Logger.getLogger(FrmFacturas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_cbxCodigo2ItemStateChanged

    private void cbxCodigo3ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxCodigo3ItemStateChanged
        try {
            Factura factura = new Factura("root","pearljam99","neptuno", "localhost:3308");
            factura.conectarFactura();
            ResultSet rsProducto1 = factura.consultarProducto(cbxCodigo3.getSelectedItem().toString());
            while (rsProducto1.next())
            {
                txt9.setText(rsProducto1.getObject(1).toString());
                txt11.setText(rsProducto1.getObject(2).toString());
                
            }
            factura.cerrarFactura();
        } catch (SQLException ex) {
            Logger.getLogger(FrmFacturas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_cbxCodigo3ItemStateChanged

    private void cbxCodigo4ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxCodigo4ItemStateChanged
        try {
            Factura factura = new Factura("root","pearljam99","neptuno", "localhost:3308");
            factura.conectarFactura();
            ResultSet rsProducto1 = factura.consultarProducto(cbxCodigo4.getSelectedItem().toString());
            while (rsProducto1.next())
            {
                txt13.setText(rsProducto1.getObject(1).toString());
                txt15.setText(rsProducto1.getObject(2).toString());
                
            }
            factura.cerrarFactura();
        } catch (SQLException ex) {
            Logger.getLogger(FrmFacturas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_cbxCodigo4ItemStateChanged

    private void txt2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt2KeyReleased
        
    }//GEN-LAST:event_txt2KeyReleased

    private void txt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt2ActionPerformed

    private void cbxClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxClienteActionPerformed
        //
        try {
            //if(estado==1)
            {
            Factura factura = new Factura("root","pearljam99","neptuno","localhost:3308");
            factura.conectarFactura();
            ResultSet rsCliente = factura.consultarClientes(cbxCliente.getSelectedItem().toString());
            while (rsCliente.next())
            {
                String idCliente = rsCliente.getObject(1).toString();
                txtDireccion.setText(rsCliente.getObject(2).toString());
                txtTelefono.setText(rsCliente.getObject(3).toString());
            }
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(FrmFacturas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_cbxClienteActionPerformed

    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameOpened

        lblNumero.setText(String.valueOf(num));
        num++;
    }//GEN-LAST:event_formInternalFrameOpened

    private void formInternalFrameActivated(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameActivated
   
    }//GEN-LAST:event_formInternalFrameActivated


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnImprimir;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JComboBox<String> cbxCliente;
    private javax.swing.JComboBox<String> cbxCodigo1;
    private javax.swing.JComboBox<String> cbxCodigo2;
    private javax.swing.JComboBox<String> cbxCodigo3;
    private javax.swing.JComboBox<String> cbxCodigo4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel lblCantidad;
    private javax.swing.JLabel lblCodigo;
    private javax.swing.JLabel lblDescripcion;
    private javax.swing.JLabel lblDescuento;
    private javax.swing.JLabel lblIVA;
    private javax.swing.JLabel lblNumero;
    private javax.swing.JLabel lblPrecio;
    private javax.swing.JLabel lblSubt;
    private javax.swing.JLabel lblSubtotal;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JLabel lblpor;
    private javax.swing.JLabel lblpor1;
    private javax.swing.JTextField txt1;
    private javax.swing.JTextField txt10;
    private javax.swing.JTextField txt11;
    private javax.swing.JTextField txt12;
    private javax.swing.JTextField txt13;
    private javax.swing.JTextField txt14;
    private javax.swing.JTextField txt15;
    private javax.swing.JTextField txt16;
    private javax.swing.JTextField txt2;
    private javax.swing.JTextField txt3;
    private javax.swing.JTextField txt4;
    private javax.swing.JTextField txt5;
    private javax.swing.JTextField txt6;
    private javax.swing.JTextField txt7;
    private javax.swing.JTextField txt8;
    private javax.swing.JTextField txt9;
    private javax.swing.JTextField txtDescuento;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtIva;
    private javax.swing.JTextField txtTelefono;
    private javax.swing.JTextField txtdescuento;
    private javax.swing.JTextField txtiva;
    private javax.swing.JTextField txtsubtotal;
    private javax.swing.JTextField txttotal;
    // End of variables declaration//GEN-END:variables

//    @Override
//    public void keyTyped(KeyEvent ke) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

//    @Override
//    public void keyPressed(KeyEvent ke) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

//    @Override
//    public void keyReleased(KeyEvent ke) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
}
