/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neptuno;

/**
 *
 * @author samue
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Productos {

    String idProducto;
    String NombreProducto;
    String idProveedor;
    String idCategoría;
    String CantidadPorUnidad;
    String PrecioUnidad;
    String UnidadesEnExistencia;
    String UnidadesEnPedido;
    String NivelNuevoPedido;
    String Suspendido;
    
    private String user;
    private String password;
    private String db;
    private String host;
    private String url;
    private Connection conn = null;
    private Statement stm;// 
    
     public Productos (String usuario, String contraseña, String bd, String servidor)
    {
        this.user = usuario;
        this.password = contraseña;
        this.db = bd;
        this.host = servidor;
//        this.url = "jdbc:mysql://" + this.host + "/" + this.db;
	this.url = "jdbc:mysql://" + this.host + "/" + this.db+"?useSSL=false&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
    }
    public void conectarProductos()
    {
         try {
                Class.forName("com.mysql.cj.jdbc.Driver");//com.mysql.cj.jdbc.Driver
                conn = DriverManager.getConnection(url, user, password);
                if (conn != null)
                {
                    System.out.println("Conexión a base de datos "+url+" ... Ok");
                    stm = conn.createStatement();
                }
            }   
        catch(SQLException ex) {
            System.out.println("Problema en la conexión a la base de datos "+url);
        }
        catch(ClassNotFoundException ex) {
            System.out.println(ex);
        }
        
    }
    public void cerrarProductos()
    {
        try{
            if(conn !=null){
                stm.close();
                conn.close();
                System.out.println("Conexión cerrada");
            }
        }
        catch(SQLException ex){
            System.out.println(ex);
        }
    }
    
    public ResultSet cargarProveedores() throws SQLException   
    {
        return stm.executeQuery("select nombreCompañía from proveedores");

    }

    public ResultSet consultarProveedor(String nombre) throws SQLException
    {
        return stm.executeQuery("select idProveedor from proveedores where nombreCompañía = '"+nombre+"' ");
    }
    
    public ResultSet cargarCategorias() throws SQLException    
    {
        return stm.executeQuery("select nombreCategoría from categorías");

    }
    
    public ResultSet consultarCategoria(String nombre) throws SQLException
    {
        return stm.executeQuery("select idCategoría from categorías where nombreCategoría = '"+nombre+"' ");
    }
    
    public String guardarProducto (String idProducto, String NombreProducto, String idProveedor, String idCategoría, String CantidadPorUnidad, String PrecioUnidad, String UnidadesEnExistencia, String UnidadesEnPedido, String NivelNuevoPedido, String Suspendido)
    {
        try {
        stm.execute("INSERT INTO productos (idProducto, NombreProducto, idProveedor, idCategoría, CantidadPorUnidad, PrecioUnidad, UnidadesEnExistencia, UnidadesEnPedido, NivelNuevoPedido, Suspendido) VALUES ('"+idProducto+"','"+NombreProducto+"','"+idProveedor+"','"+idCategoría+"','"+CantidadPorUnidad+"','"+PrecioUnidad+"','"+UnidadesEnExistencia+"','"+UnidadesEnPedido+"','"+NivelNuevoPedido+"','"+Suspendido+"' )");
                return "El registro se ha guardado con éxito";
                } catch (SQLException ex) {
                    Logger.getLogger(Productos.class.getName()).log(Level.SEVERE, null, ex);
                    return "El registro no se ha guardado con éxito";
                }
    }
    
    public String modificarProducto (String idProducto, String NombreProducto, String idProveedor, String idCategoría, String CantidadPorUnidad, String PrecioUnidad, String UnidadesEnExistencia, String UnidadesEnPedido, String NivelNuevoPedido, String Suspendido)
    {
        try {
            stm.execute ("UPDATE productos SET nombreProducto='"+NombreProducto+"',idProveedor='"+idProveedor+"',idCategoría='"+idCategoría+"',CantidadPorUnidad='"+CantidadPorUnidad+"',PrecioUnidad='"+PrecioUnidad+"',UnidadesEnExistencia='"+UnidadesEnExistencia+"',UnidadesEnPedido='"+UnidadesEnPedido+"',NivelNuevoPedido='"+NivelNuevoPedido+"',Suspendido='"+Suspendido+"' WHERE idProducto='"+idProducto+"' ");
            return "El registro se ha modificado con éxito";
        } catch (SQLException ex) {
            Logger.getLogger(Productos.class.getName()).log(Level.SEVERE, null, ex);
            return "El registro no se ha modificado";
        }
    }
    
    public String eliminarClientes(String id)
    {
        try {
            stm.execute(" DELETE FROM productos WHERE idProductos='"+id+"' ");
            return "Registro Borrado";
        } catch (SQLException ex) {
            Logger.getLogger(Productos.class.getName()).log(Level.SEVERE, null, ex);
            return "No se pudo borrar el registro";
        }
    }
     
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
